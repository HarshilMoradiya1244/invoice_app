import 'package:flutter/cupertino.dart';
import 'package:invoice_app/screen/Invoice_screen.dart';
import 'package:invoice_app/screen/home_screen.dart';

Map<String,WidgetBuilder>invoice_routes = {
  '/':(context) => HomeScreen(),
  'invoice':(context) =>InvoiceGenrator(),
};