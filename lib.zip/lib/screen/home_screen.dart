import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List <TextEditingController> datalist=[];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text(" Invoice Maker ",style: TextStyle(fontSize: 20,color:Colors.white),),
          leading:IconButton(onPressed: (){},icon: Icon(Icons.arrow_back),),
            actions: [
            IconButton(onPressed: (){
              Navigator.pushNamed(context,'invoice');
            },icon: Icon(Icons.add),)
           ],
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 10),
              Container(
                height: MediaQuery.of(context).size.height * 0.5,
                width: MediaQuery.of(context).size.width * 0.9,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(5),color: Colors.white),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Text("Enter The Skill",style: TextStyle(fontSize:20,),),
                      Column(
                        children:datalist.asMap().entries.map((e) =>TextField(
                          controller: e.value,
                          decoration: InputDecoration(
                              hintText: 'C Language , Web Technical',hintStyle:TextStyle(color: Colors.grey.shade400),
                              suffixIcon:IconButton(onPressed: (){
                                setState(() {
                                  datalist.removeAt(e.key);

                                });
                              },icon: Icon(Icons.delete),)
                          ),
                        )
                        ).toList(),
                      ),
                      SizedBox(height: 10),
                      Container(
                        height:50,
                        width:MediaQuery.of(context).size.width*0.9,
                        decoration:BoxDecoration(border:Border.all(width: 1,color: Colors.black) ),
                        child: IconButton(onPressed: (){
                          setState(() {
                            datalist.add(TextEditingController());
                          });
                        },icon: Icon(Icons.add)),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
