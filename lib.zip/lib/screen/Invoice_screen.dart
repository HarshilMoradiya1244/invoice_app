import 'package:flutter/material.dart';

class InvoiceGenrator extends StatefulWidget {
  const InvoiceGenrator({super.key});

  @override
  State<InvoiceGenrator> createState() => _InvoiceGenratorState();
}

class _InvoiceGenratorState extends State<InvoiceGenrator> {
  @override
  Widget build(BuildContext context) {
    return  SafeArea(
      child: Scaffold(
      appBar: AppBar(
      centerTitle: true,
      title: Text(" Invoice Genrate ",style: TextStyle(fontSize: 20,color:Colors.white),),
      leading:IconButton(onPressed: (){},icon: Icon(Icons.menu),),
      actions: [
        IconButton(onPressed: (){},icon: Icon(Icons.share),),
        IconButton(onPressed: (){},icon: Icon(Icons.picture_as_pdf),)
      ],
    ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                TextField(
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    label: Text(
                      "Choose Customer Name -",style: TextStyle(color:Colors.grey.shade400,fontWeight: FontWeight.bold),
                    ),
                    hintText:'Choose Customer Name -',hintStyle:TextStyle(color:Colors.black,fontWeight: FontWeight.bold)
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    label: Text(
                      "invoice No",style: TextStyle(color:Colors.grey.shade400,fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    label: Text(
                      "Product Name",style: TextStyle(color:Colors.grey.shade400,fontWeight: FontWeight.bold),
                    ),
                      hintText:'Choose product',hintStyle:TextStyle(color:Colors.black,fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    label: Text(
                      "Type",style: TextStyle(color:Colors.grey.shade400,fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    label: Text(
                      "Choose Customer Name -",style: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    SizedBox(
                      width:190,
                      child: TextField(
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          label: Text(
                            "Quantity",style: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width:10),
                    SizedBox(
                      width:190,
                      child: TextField(
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          label: Text(
                            "prizes",style: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                ElevatedButton(onPressed:(){}, child:Text("Submit")),
                Divider(
                  thickness:2,
                  color: Colors.grey.shade400,
                ),
                SizedBox(height: 10),
                Text("Total Payment : 0.00TK",style: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),)
              ],
            ),
          ),
        ),
    ),
    );
  }
}