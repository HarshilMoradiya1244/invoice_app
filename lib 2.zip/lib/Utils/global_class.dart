class Global{

  static Global g1 = Global();
  List InvoiceList=[];
}